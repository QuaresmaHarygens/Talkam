# Talkam Liberia Delivery Package

This repository contains the design + planning artifacts for the Talkam Liberia social reporting system. All deliverables requested by the brief are inside the `artifacts/` directory alongside supporting assets.

## Contents
- Architecture diagrams & spec (`artifacts/architecture`)
- Wireframes & clickable prototype JSON (`artifacts/wireframes`)
- Branding package & app icons (`artifacts/branding`)
- Flowchart visuals (`artifacts/flowcharts`)
- Technical specs + OpenAPI (`artifacts/specs`)
- Database schema & seed data (`artifacts/data`)
- Product docs (roadmap, monetization, security, QA, devops, moderation, user stories, handoff) under `artifacts/docs`
- UX guidelines (`artifacts/ux`)
- Analytics spec + mockup (`artifacts/analytics`)
- Promotional copy (`artifacts/copy`)

## Getting Started (Developers)
1. **Clone & install prerequisites**
   - Python 3.10+, Poetry or pipenv for backend.
   - Flutter 3.x + fvm recommended.
   - Docker Desktop (for Postgres, Redis, MinIO, RabbitMQ).
2. **Spin up local stack**
   ```sh
   docker compose up db redis minio mq
   psql -h localhost -U postgres -f artifacts/data/schema.sql
   uvicorn app.main:app --reload
   ```
3. **Generate API clients** using `artifacts/specs/openapi.yaml` with `openapi-generator-cli`.
4. **Load sample data** (SAMPLE/SEED) to test flows and analytics dashboards.
5. **Review UX assets** and import PNG/SVG into Figma or Flutter widgetbook for implementation.

## Pilot Launch Checklist
- Select target county (e.g., Montserrado) and partner NGO/government agency.
- Pre-load county boundaries + offline basemaps for pilot area.
- Train moderators + responders on verification, embargo, and panic delete procedures.
- Configure SMS gateway short codes with local telcos.
- Run tabletop exercise simulating life-threatening escalation.
- Collect feedback via user testing script (see `artifacts/docs/qa-testing.md`).

## Next Steps
- Convert specs into implementation tasks (Jira/Linear) per roadmap phases.
- Stand up monitoring dashboards (Prometheus/Grafana + Sentry) ahead of MVP.
- Formalize data-sharing agreements and privacy disclosures before public launch.

All sample data, names, and locations are fictional and labeled as SAMPLE/SEED.
