# Sample User Stories (SAMPLE DATA)
- As a market vendor, I want to report a road blockage with a photo so authorities know to clear it.
- As an NGO investigator, I want to download verified reports in CSV so I can prioritize aid.
- As an anonymous witness, I want my voice masked so I can safely report political intimidation.
- As an admin, I want to see flagged posts and evidence so I can moderate.
